package umcStudy.week9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
